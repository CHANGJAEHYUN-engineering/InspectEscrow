"use strict";

const {Contract,TypedDataEncoder,formatEther,hexlify,keccak256,randomBytes,toUtf8Bytes}=require("ethers");
const {commitment,hashObject}=require("./evidence-bridge.cjs");
const {getDetail,STATE_NAMES}=require("./trade-workspace-endpoints.cjs");
const {verifyReportEnvelope}=require("./replay-endpoints.cjs");
const {domain,replayTypes}=require("./e2e-endpoints.cjs");

const ZERO="0x"+"00".repeat(32);
const ARCHIVED_REPLAY_PROVENANCE={
 supplierBundleSha256:"6a7b2d36cca29b8a883985523adcb0cd55984d4b42d9e18482ea812b2c61c52e",
 reviewWrapperSha256:"a5e1b962c5835fc11ef9483a878c3e3f13c9aab4984d2e35328222861fb8686f",
 checkpointSha256:"8320d4cab14d071ae65911d59d5ddf608a1a514e0bfdba0c4345d27da94a3854",
 supplierTopSha256:"0609922596edc39c6f8db095d7a820d36f87c9492e1f6ffd28936e4d9b888991",
 buyerTopSha256:"a6f9827f2b2d19ada3e6143a2b6983784afd4b4d22c28d6e45d65fbed036a370"
};
const eq=(a,b)=>String(a||"").toLowerCase()===String(b||"").toLowerCase();
const fail=code=>{throw Error(code);};
const assert=(value,code)=>{if(!value)fail(code);};
const registryAbi=["function status(address) view returns (uint8)"];
const decisionTypes={InspectorDecisionAttestation:[
 ["tradeId","bytes32"],["stage","uint8"],["inspectorActor","address"],["policyHash","bytes32"],
 ["supplierEvidenceHash","bytes32"],["buyerEvidenceHash","bytes32"],["replayReportHash","bytes32"],
 ["decision","uint8"],["reasonCode","bytes32"],["decisionEvidenceHash","bytes32"],["nonce","bytes32"],
 ["issuedAt","uint64"],["validUntil","uint64"]
].map(([name,type])=>({name,type}))};
const arbitrationTypes={ArbitrationDecisionAttestation:[
 ["tradeId","bytes32"],["arbitratorActor","address"],["policyHash","bytes32"],
 ["supplierEvidenceHash","bytes32"],["buyerEvidenceHash","bytes32"],["decision","uint8"],
 ["reasonCode","bytes32"],["decisionEvidenceHash","bytes32"],["nonce","bytes32"],
 ["issuedAt","uint64"],["validUntil","uint64"]
].map(([name,type])=>({name,type}))};
const mutualTypes={MutualResolution:[
 ["tradeId","bytes32"],["outcome","uint8"],["resolutionNonce","bytes32"],["deadline","uint64"]
].map(([name,type])=>({name,type}))};

function readBody(req,max=2*1024*1024){return new Promise((resolve,reject)=>{const chunks=[];let size=0,done=false;req.on("data",chunk=>{if(done)return;size+=chunk.length;if(size>max){done=true;reject(Error("REQUEST_TOO_LARGE"));req.destroy();return;}chunks.push(chunk);});req.on("error",reject);req.on("end",()=>{if(done)return;try{resolve(JSON.parse(Buffer.concat(chunks).toString("utf8")));}catch{reject(Error("INVALID_JSON"));}});});}
const send=(res,code,value)=>{res.writeHead(code,{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store","X-Content-Type-Options":"nosniff"});res.end(JSON.stringify(value));};
function activeStage(snapshot){if(snapshot.state===12)return{stage:0,actor:snapshot.roles.primaryInspector,station:snapshot.roles.primaryInspectorStation};if(snapshot.state===13)return{stage:1,actor:snapshot.roles.backupInspector,station:snapshot.roles.backupInspectorStation};return null;}
function deadlinePhase(snapshot){if(!snapshot.deadline)return"NONE";return snapshot.blockTimestamp>snapshot.deadline?"EXPIRED":"OPEN";}
function action(id,label,func,role,enabled,reason,extra={}){return{id,label,function:func,role,enabled:Boolean(enabled),reason,...extra};}

function deriveActionMatrix(snapshot,selectedActor=""){
 const state=Number(snapshot.state),now=Number(snapshot.blockTimestamp),deadline=Number(snapshot.deadline||0),expired=deadline>0&&now>deadline;
 const actor=String(selectedActor||"").toLowerCase(),roles=snapshot.roles,claimable=snapshot.claimable||{};
 const is=address=>!actor||eq(actor,address),governance=Boolean(snapshot.policyApproved),result=[];
 const add=(id,label,func,role,address,condition,reason,extra={})=>result.push(action(id,label,func,role,condition&&is(address),!condition?reason:(!is(address)?"현재 지갑이 필요한 Actor가 아닙니다.":"실행 전 최신 상태·staticCall·gas·사용자 승인을 다시 확인합니다."),{expectedActor:address,...extra}));
 if(state===7){add("supplier-reinspect","Supplier 재검사 요청","requestSupplierReinspection","Supplier",roles.supplier,governance,"SUPPLIER_HOLD와 정책 승인이 필요합니다.");add("supplier-abandon","Supplier hold 종료·Buyer 환급","abandonSupplierHold","Supplier",roles.supplier,true,"SUPPLIER_HOLD가 필요합니다.");add("supplier-hold-timeout","Supplier hold timeout","invokeSupplierHoldTimeout","Any",null,expired,"deadline이 아직 지나지 않았습니다.",{permissionless:true});}
 if(state===11){add("accept-release","Buyer 수락·Supplier 정산","acceptAndRelease","Buyer",roles.buyer,governance&&snapshot.inspections.buyer.outcome===2,"ACCEPTANCE_PENDING, Buyer PASS, 정책 승인이 필요합니다.");add("accept-timeout","수락 기한 종료·Supplier 정산","invokeAcceptanceTimeout","Any",null,expired,"deadline이 아직 지나지 않았습니다.",{permissionless:true});}
 if(state===12||state===13){const active=activeStage(snapshot);add("record-replay","검증된 Replay 기록","recordReplayResult",state===12?"Primary Inspector":"Backup Inspector",active.actor,governance&&snapshot.replay.status===0&&!expired,"분쟁 상태, 미사용 Replay, 유효 기한, 정책 승인이 필요합니다.",{requiresStation:true,expectedStation:active.station});add("inspector-decision","Inspector 독립 정산 판단","submitInspectorDecision",state===12?"Primary Inspector":"Backup Inspector",active.actor,governance&&snapshot.replay.status===1&&!expired,"CONSISTENT Replay, 유효 기한, 정책 승인이 필요합니다.",{requiresStation:true,expectedStation:active.station});if(state===12)add("activate-backup","Primary timeout → Backup","activateBackupInspector","Any",null,expired,"Primary deadline이 아직 지나지 않았습니다.",{permissionless:true});else add("backup-timeout","Backup timeout → ESCALATED","escalateAfterBackupTimeout","Any",null,expired,"Backup deadline이 아직 지나지 않았습니다.",{permissionless:true});}
 if([10,14,15,16].includes(state)){add("mutual-resolve","Supplier·Buyer 상호 해결","mutualResolve","Supplier + Buyer",null,!expired,"상호 해결 deadline이 지났습니다.",{requiresDualSignature:true});add("external-arbitration","External Arbitration 개시","escalateToExternalArbitration","Any",null,expired,"상호 해결 deadline이 아직 지나지 않았습니다.",{permissionless:true});}
 if(state===20){add("arbitration-decision","External Arbitrator 판단","submitArbitrationDecision","External Arbitrator",roles.externalArbitrator,governance&&!expired,"중재 기한과 정책 승인이 필요합니다.",{requiresStation:true,expectedStation:roles.externalArbitratorStation});add("final-fallback","중재 timeout 고정 fallback","executeFinalFallback","Any",null,expired,"중재 deadline이 아직 지나지 않았습니다.",{permissionless:true});}
 if(state===5)add("supplier-timeout","Supplier 검사 timeout 환급","invokeSupplierInspectionTimeout","Any",null,expired,"Supplier 검사 deadline이 아직 지나지 않았습니다.",{permissionless:true});
 if(state===6||state===9)add("reinspection-timeout","재검사 timeout 처리","invokeReinspectionTimeout","Any",null,expired,"재검사 deadline이 아직 지나지 않았습니다.",{permissionless:true});
 if(state===8)add("buyer-timeout","Buyer 검사 timeout 보호 상태","invokeBuyerInspectionTimeout","Any",null,expired,"Buyer 검사 deadline이 아직 지나지 않았습니다.",{permissionless:true});
 for(const [role,address] of [["Supplier",roles.supplier],["Buyer",roles.buyer]]){const amount=BigInt(claimable[role.toLowerCase()]?.wei||"0");if(amount>0n)add("withdraw-"+role.toLowerCase(),role+" claimable Withdraw","withdraw",role,address,true,"claimable이 없습니다.",{amountWei:"0",claimableWei:String(amount)});}
 return result;
}

async function resolutionContext(ctx,tradeId,selectedActor=""){
 assert(/^0x[0-9a-fA-F]{64}$/.test(tradeId),"TRADE_ID_INVALID");
 const detail=await getDetail(ctx,tradeId),block=await ctx.provider.getBlock("latest"),network=await ctx.provider.getNetwork();
 const registryAddress=await ctx.contract.credentialRegistry(),roles=detail.roles,registry=new Contract(registryAddress,registryAbi,ctx.provider);
 const addresses=[roles.supplier,roles.buyer,roles.primaryInspector,roles.backupInspector,roles.externalArbitrator];
 const stationEntries=[["supplierStation",roles.supplierStation],["buyerStation",roles.buyerStation],["primaryInspectorStation",roles.primaryInspectorStation],["backupInspectorStation",roles.backupInspectorStation],["externalArbitratorStation",roles.externalArbitratorStation]];
 const [claims,statuses,totalFunded,totalWithdrawn,outstanding,unsettled,escrowBalance]=await Promise.all([
  Promise.all(addresses.map(address=>ctx.contract.claimable(address))),Promise.all(stationEntries.map(([,address])=>registry.status(address))),ctx.contract.totalFunded(),ctx.contract.totalWithdrawn(),ctx.contract.outstandingClaimable(),ctx.contract.unsettledEscrow(),ctx.provider.getBalance(String(ctx.contract.target))
 ]);
 const policyApproved=detail.kind==="DYNAMIC_ONCHAIN_TRADE"?detail.state>=2:detail.policy.documentApproval.approved;
 const snapshot={source:Number(network.chainId)===11155111?"LIVE_SEPOLIA_READ_ONLY":"LOCAL_ANVIL_READ_ONLY",readOnly:true,serverTransactionsSent:0,chainId:Number(network.chainId),contract:String(ctx.contract.target),credentialRegistry:registryAddress,domain:{name:"InspectEscrow",version:"1",chainId:Number(network.chainId),verifyingContract:String(ctx.contract.target)},blockNumber:block.number,blockTimestamp:Number(block.timestamp),tradeId:detail.id,state:detail.state,stateName:detail.stateName,settled:detail.settled,deadline:detail.deadline,deadlinePhase:deadlinePhase({...detail,blockTimestamp:Number(block.timestamp)}),remainingSeconds:detail.deadline?detail.deadline-Number(block.timestamp):null,policyHash:detail.terms.policyHash,policyDocumentStatus:detail.policy.documentApproval.status,policyApproved,policyHashVerified:detail.policy.immutableHash.verified,policyExecutionGate:policyApproved?"ONCHAIN_ACCEPTANCE_OR_APPROVED_POLICY":"BLOCKED_DRAFT_POLICY_USER_DECISION_REQUIRED",roles,inspections:detail.inspections,replay:{status:detail.replay.status,statusName:["NONE","CONSISTENT","INCONSISTENT"][detail.replay.status]||"UNKNOWN",reportHash:detail.replay.reportHash},withdrawal:detail.withdrawal,claimable:{supplier:{address:roles.supplier,wei:String(claims[0]),eth:formatEther(claims[0])},buyer:{address:roles.buyer,wei:String(claims[1]),eth:formatEther(claims[1])},primaryInspector:{address:roles.primaryInspector,wei:String(claims[2]),eth:formatEther(claims[2])},backupInspector:{address:roles.backupInspector,wei:String(claims[3]),eth:formatEther(claims[3])},externalArbitrator:{address:roles.externalArbitrator,wei:String(claims[4]),eth:formatEther(claims[4])}},credentials:Object.fromEntries(stationEntries.map(([name,address],i)=>[name,{address,status:Number(statuses[i]),active:Number(statuses[i])===1}])),accounting:{conserved:detail.accounting.conserved,balanceCoversLiabilities:detail.accounting.balanceCoversLiabilities,totalFundedWei:String(totalFunded),totalWithdrawnWei:String(totalWithdrawn),outstandingClaimableWei:String(outstanding),unsettledEscrowWei:String(unsettled),escrowBalanceWei:String(escrowBalance)},transactions:detail.transactions};
 snapshot.actions=deriveActionMatrix(snapshot,selectedActor);snapshot.activeInspector=activeStage(snapshot);return snapshot;
}

async function finalizeTypedPackage(ctx,snapshot,kind,types,message,station,actor,func,extra={}){
 const digest=TypedDataEncoder.hash(snapshot.domain,types,message),hashFn=kind==="replay"?"hashReplayAttestation":kind==="decision"?"hashInspectorDecision":kind==="arbitration"?"hashArbitrationDecision":"hashMutualResolution";
 const contractDigest=await ctx.contract[hashFn](message);assert(eq(digest,contractDigest),"EIP712_CONTRACT_DIGEST_MISMATCH");
 if(kind!=="mutual"){assert(snapshot.credentials[extra.credentialKey]?.active===true,"STATION_CREDENTIAL_NOT_ACTIVE");assert(await ctx.contract.consumedDigest(digest)===false,"DIGEST_ALREADY_CONSUMED");}
 return{stage:"UNSIGNED_EIP712_NOT_ONCHAIN",kind,function:func,actor,station,domain:snapshot.domain,types,message,digest,contractDigest,signature:null,transactionsSent:0,...extra};
}
function freshWindow(snapshot){assert(snapshot.deadline&&snapshot.blockTimestamp<snapshot.deadline-60,"BLOCKED_DEADLINE_INSUFFICIENT");return{issuedAt:snapshot.blockTimestamp,validUntil:Math.min(snapshot.deadline,snapshot.blockTimestamp+600)};}
function assertWriteGovernance(snapshot){assert(snapshot.policyHashVerified,"POLICY_HASH_UNVERIFIED");assert(snapshot.policyApproved,"DRAFT_POLICY_NOT_APPROVED_FOR_ONCHAIN");}
function assertArchivedReplay(snapshot,report){
 if(report.replayExecutionStatus!=="NOT_RUN_RESOURCE_CONSTRAINT")return;
 assert(snapshot.chainId!==11155111,"ARCHIVED_REPLAY_LOCAL_ANVIL_ONLY");
 assert(report.currentRunAiReplayExecuted===false,"CURRENT_RUN_AI_STATUS_INVALID");
 assert(report.independentAiReplayExecuted===true,"HISTORICAL_AI_REPLAY_PROVENANCE_REQUIRED");
 const p=report.archivedProvenance||{};
 for(const [key,value] of Object.entries(ARCHIVED_REPLAY_PROVENANCE))assert(eq(p[key],value),"ARCHIVED_REPLAY_PROVENANCE_MISMATCH_"+key.toUpperCase());
 assert(String(report.replayToleranceScaled)==="0","ARCHIVED_REPLAY_TOLERANCE_MUST_BE_ZERO");
 const supplier=report.roles?.supplier,buyer=report.roles?.buyer;
 assert(supplier?.topInputSha256===ARCHIVED_REPLAY_PROVENANCE.supplierTopSha256,"ARCHIVED_SUPPLIER_TOP_MISMATCH");
 assert(buyer?.topInputSha256===ARCHIVED_REPLAY_PROVENANCE.buyerTopSha256,"ARCHIVED_BUYER_TOP_MISMATCH");
 assert(String(supplier?.replayScoreScaled)==="36302902","ARCHIVED_SUPPLIER_SCORE_MISMATCH");
 assert(String(buyer?.replayScoreScaled)==="52572132","ARCHIVED_BUYER_SCORE_MISMATCH");
 if(report.status==="CONSISTENT"){
  assert(String(supplier.comparedSubmittedScoreScaled)==="36302902"&&String(buyer.comparedSubmittedScoreScaled)==="52572132","ARCHIVED_CONSISTENT_CLAIM_MISMATCH");
  assert(String(supplier.absoluteErrorScaled)==="0"&&String(buyer.absoluteErrorScaled)==="0","ARCHIVED_CONSISTENT_ERROR_MISMATCH");
 }else{
  assert(report.controlledRedTeam?.label==="CONTROLLED RED-TEAM TEST","CONTROLLED_RED_TEAM_LABEL_REQUIRED");
  assert(report.controlledRedTeam?.maliciousClaimIsActualModelOutput===false,"CONTROLLED_CLAIM_TRUTH_LABEL_REQUIRED");
  assert(String(buyer.comparedSubmittedScoreScaled)==="52572133"&&String(buyer.absoluteErrorScaled)==="1","CONTROLLED_SCORE_DELTA_MISMATCH");
 }
}
function assertReport(snapshot,envelope,expectedStatus){const verified=verifyReportEnvelope(envelope);assert(eq(verified.tradeId,snapshot.tradeId),"REPORT_TRADE_MISMATCH");assert(eq(envelope.report.policyHash,snapshot.policyHash),"REPORT_POLICY_MISMATCH");assert(envelope.report.mode==="INDEPENDENT_MODEL_B_REPLAY","CONTROLLED_OR_SYNTHETIC_REPORT_NOT_SUBMITTABLE");assert(envelope.report.status===expectedStatus,"REPLAY_REPORT_STATUS_INVALID_FOR_ACTION");assert(eq(envelope.report.roles.supplier.evidencePackageHash,snapshot.inspections.supplier.evidencePackageHash),"SUPPLIER_EVIDENCE_MISMATCH");assert(eq(envelope.report.roles.buyer.evidencePackageHash,snapshot.inspections.buyer.evidencePackageHash),"BUYER_EVIDENCE_MISMATCH");assertArchivedReplay(snapshot,envelope.report);return verified;}

async function prepareReplay(ctx,body){const snapshot=await resolutionContext(ctx,String(body.tradeId||""));assertWriteGovernance(snapshot);const active=snapshot.activeInspector;assert(active&&snapshot.replay.status===0,"REPLAY_NOT_ALLOWED_IN_CURRENT_STATE");const expected=body.reportEnvelope?.report?.status;assert(expected==="CONSISTENT"||expected==="INCONSISTENT","REPLAY_REPORT_MUST_BE_VERIFIED");assertReport(snapshot,body.reportEnvelope,expected);const time=freshWindow(snapshot),message={tradeId:snapshot.tradeId,stage:active.stage,inspectorActor:active.actor,policyHash:snapshot.policyHash,supplierEvidenceHash:snapshot.inspections.supplier.evidencePackageHash,buyerEvidenceHash:snapshot.inspections.buyer.evidencePackageHash,replayReportHash:body.reportEnvelope.replayReportHash,consistent:expected==="CONSISTENT",nonce:hexlify(randomBytes(32)),...time};return finalizeTypedPackage(ctx,snapshot,"replay",replayTypes,message,active.station,active.actor,"recordReplayResult",{credentialKey:active.stage===0?"primaryInspectorStation":"backupInspectorStation",reportStatus:expected});}
async function prepareDecision(ctx,body){const snapshot=await resolutionContext(ctx,String(body.tradeId||""));assertWriteGovernance(snapshot);const active=snapshot.activeInspector;assert(active&&snapshot.replay.status===1,"CONSISTENT_ONCHAIN_REPLAY_REQUIRED");assertReport(snapshot,body.reportEnvelope,"CONSISTENT");assert(eq(body.reportEnvelope.replayReportHash,snapshot.replay.reportHash),"ONCHAIN_REPLAY_HASH_MISMATCH");const decision=Number(body.decision);assert(decision===1||decision===2,"DECISION_REQUIRED");const reason=String(body.reason||"").trim(),evidenceText=String(body.evidenceText||"").trim();assert(reason.length>=8&&reason.length<=500,"DECISION_REASON_LENGTH_INVALID");assert(evidenceText.length>=8&&evidenceText.length<=2000,"DECISION_EVIDENCE_LENGTH_INVALID");const reasonCode=keccak256(toUtf8Bytes("INSPECTOR_REASON:"+reason)),decisionEvidence={schema:"inspectescrow.inspector-decision-evidence/1",tradeId:snapshot.tradeId,replayReportHash:snapshot.replay.reportHash,decision,reason,evidenceText,policyHash:snapshot.policyHash,preparedAtBlock:snapshot.blockNumber,automaticDecision:false},decisionEvidenceHash=hashObject(decisionEvidence),time=freshWindow(snapshot),message={tradeId:snapshot.tradeId,stage:active.stage,inspectorActor:active.actor,policyHash:snapshot.policyHash,supplierEvidenceHash:snapshot.inspections.supplier.evidencePackageHash,buyerEvidenceHash:snapshot.inspections.buyer.evidencePackageHash,replayReportHash:snapshot.replay.reportHash,decision,reasonCode,decisionEvidenceHash,nonce:hexlify(randomBytes(32)),...time};return finalizeTypedPackage(ctx,snapshot,"decision",decisionTypes,message,active.station,active.actor,"submitInspectorDecision",{credentialKey:active.stage===0?"primaryInspectorStation":"backupInspectorStation",decisionEvidence});}
async function prepareArbitration(ctx,body){const snapshot=await resolutionContext(ctx,String(body.tradeId||""));assertWriteGovernance(snapshot);assert(snapshot.state===20&&snapshot.deadlinePhase==="OPEN","ARBITRATION_NOT_ALLOWED_IN_CURRENT_STATE");const decision=Number(body.decision);assert(decision===1||decision===2,"DECISION_REQUIRED");const reason=String(body.reason||"").trim(),evidenceText=String(body.evidenceText||"").trim();assert(reason.length>=8&&evidenceText.length>=8,"ARBITRATION_BASIS_REQUIRED");const reasonCode=keccak256(toUtf8Bytes("ARBITRATION_REASON:"+reason)),evidence={schema:"inspectescrow.arbitration-evidence/1",tradeId:snapshot.tradeId,decision,reason,evidenceText,policyHash:snapshot.policyHash,preparedAtBlock:snapshot.blockNumber},decisionEvidenceHash=hashObject(evidence),time=freshWindow(snapshot),message={tradeId:snapshot.tradeId,arbitratorActor:snapshot.roles.externalArbitrator,policyHash:snapshot.policyHash,supplierEvidenceHash:snapshot.inspections.supplier.evidencePackageHash,buyerEvidenceHash:snapshot.inspections.buyer.evidencePackageHash,decision,reasonCode,decisionEvidenceHash,nonce:hexlify(randomBytes(32)),...time};return finalizeTypedPackage(ctx,snapshot,"arbitration",arbitrationTypes,message,snapshot.roles.externalArbitratorStation,snapshot.roles.externalArbitrator,"submitArbitrationDecision",{credentialKey:"externalArbitratorStation",decisionEvidence:evidence});}
async function prepareMutual(ctx,body){const snapshot=await resolutionContext(ctx,String(body.tradeId||""));assert([10,14,15,16].includes(snapshot.state)&&snapshot.deadlinePhase==="OPEN","MUTUAL_RESOLUTION_NOT_ALLOWED");const outcome=Number(body.outcome);assert(outcome===1||outcome===2,"RESOLUTION_OUTCOME_REQUIRED");const message={tradeId:snapshot.tradeId,outcome,resolutionNonce:hexlify(randomBytes(32)),deadline:Math.min(snapshot.deadline,snapshot.blockTimestamp+600)};return finalizeTypedPackage(ctx,snapshot,"mutual",mutualTypes,message,null,null,"mutualResolve",{supplier:snapshot.roles.supplier,buyer:snapshot.roles.buyer});}

async function handle(req,res,ctx,url){
 if(url.pathname==="/api/resolution/context"&&req.method==="GET"){try{return send(res,200,await resolutionContext(ctx,String(url.searchParams.get("tradeId")||""),String(url.searchParams.get("actor")||"")));}catch(error){return send(res,422,{ok:false,error:String(error.shortMessage||error.message||error).slice(0,280),transactionsSent:0});}}
 if(url.pathname.startsWith("/api/resolution/prepare-")&&req.method==="POST"){
  if(req.headers.origin&&req.headers.origin!=="http://"+req.headers.host&&req.headers.origin!==process.env.INSPECTESCROW_PUBLIC_ORIGIN)return send(res,403,{ok:false,error:"ORIGIN_REJECTED",transactionsSent:0});
  if(req.headers["x-inspectescrow-local"]!=="1"||!String(req.headers["content-type"]||"").startsWith("application/json"))return send(res,403,{ok:false,error:"LOCAL_JSON_HEADER_REQUIRED",transactionsSent:0});
  try{const body=await readBody(req);const fn=url.pathname.endsWith("replay")?prepareReplay:url.pathname.endsWith("decision")?prepareDecision:url.pathname.endsWith("arbitration")?prepareArbitration:url.pathname.endsWith("mutual")?prepareMutual:null;assert(fn,"UNKNOWN_PREPARATION_ROUTE");return send(res,200,await fn(ctx,body));}catch(error){const code=String(error.shortMessage||error.message||error).slice(0,280);return send(res,422,{ok:false,status:"BLOCKED",error:code,transactionsSent:0});}
 }
 return send(res,405,{error:"METHOD_OR_ROUTE_NOT_ALLOWED"});
}

module.exports={handle,resolutionContext,deriveActionMatrix,prepareReplay,prepareDecision,prepareArbitration,prepareMutual,decisionTypes,arbitrationTypes,mutualTypes,domain,STATE_NAMES};
